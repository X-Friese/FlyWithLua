Install instruction for X-Plane 9 users
=======================================

Copy everything from inside the subfolder "X-Plane 9/Resources/plugins/FlyWithLua/32/" into this folder "X-Plane 9/Resources/plugins/FlyWithLua/".

Delete the subfolders "X-Plane 9/Resources/plugins/FlyWithLua/32/" and "X-Plane 9/Resources/plugins/FlyWithLua/64/".

Copy everything from inside the subfolder "X-Plane 9/Resources/plugins/FlyWithLua/XP9/" into this folder "X-Plane 9/Resources/plugins/FlyWithLua/" and replace the files.

Delete the subfolder "X-Plane 9/Resources/plugins/FlyWithLua/XP9/".

That's it, start X-Plane and enjoy your flight.

Linux and Mac users must do the same (if this version of FlyWithLua contains support for Linux and Mac systems).

Linux and Mac support depends on developers, who compile FlyWithLua on these systems.
I'm not able to build Linux or Mac versions, as I only own a Windows 7 system with X-Plane 10.

As an other fact of not having X-Plane 9 installed, the replacement build made for X-Plane 9
is not tested. You may use it on your own risk. I can not support X-Plane 9, sorry.

Happy landings!

Carsten Lynker